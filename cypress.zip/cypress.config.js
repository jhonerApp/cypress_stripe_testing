require('dotenv').config();

const { defineConfig } = require("cypress");

module.exports = defineConfig({
  e2e: {
    setupNodeEvents(on, config) {
      config.env.STRIPE_SECRET = process.env.CYPRESS_STRIPE_SECRET;
      return config;
    },
  },
});
