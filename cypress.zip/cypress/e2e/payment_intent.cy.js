describe('Create Stripe PaymentIntent', () => {
  it('successfully creates a PaymentIntent', () => {
    const stripeKey = Cypress.env('STRIPE_SECRET');
    cy.request({
      method: 'POST',
      url: 'https://api.stripe.com/v1/payment_intents',
      headers: {
          Authorization: 'Basic ' + btoa(`${stripeKey}:`),
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: {
        amount: 2000,
        currency: 'usd',
        'metadata[order_id]': '6735',
      },
      form: true,
    }).then((response) => {
    const body = response.body;
     expect(body).to.have.property('id').and.to.match(/^pi_/);
      expect(body.object).to.eq('payment_intent');
      expect(body.amount).to.eq(2000);
      expect(body.amount_capturable).to.eq(0);
      expect(body.amount_details).to.deep.eq({ tip: {} });
      expect(body.amount_received).to.eq(0);
      expect(body.application).to.be.null;
      expect(body.application_fee_amount).to.be.null;
      expect(body.automatic_payment_methods.enabled).to.eq(true);
      expect(body.canceled_at).to.be.null;
      expect(body.cancellation_reason).to.be.null;
      expect(body.capture_method).to.match(/^automatic/); 
      expect(body.client_secret).to.include(body.id); 
      expect(body.confirmation_method).to.eq('automatic');
      expect(body.currency).to.eq('usd');
      expect(body.customer).to.be.null;
      expect(body.description).to.be.null;
      expect(body.last_payment_error).to.be.null;
      expect(body.latest_charge).to.be.null;
      expect(body.livemode).to.eq(false);
      expect(body.metadata).to.deep.eq({ order_id: '6735' });
      expect(body.next_action).to.be.null;
      expect(body.on_behalf_of).to.be.null;
      expect(body.payment_method).to.be.null;
      expect(body.payment_method_options).to.have.property('card');
      expect(body.payment_method_options.card.request_three_d_secure).to.eq('automatic');
      expect(body.payment_method_types).to.include.members(['card', 'link']);
      expect(body.processing).to.be.null;
      expect(body.receipt_email).to.be.null;
      expect(body.review).to.be.null;
      expect(body.setup_future_usage).to.be.null;
      expect(body.shipping).to.be.null;
      expect(body.source).to.be.null;
      expect(body.statement_descriptor).to.be.null;
      expect(body.statement_descriptor_suffix).to.be.null;
      expect(body.status).to.eq('requires_payment_method');
      expect(body.transfer_data).to.be.null;
      expect(body.transfer_group).to.be.null;
    });
  });
});
